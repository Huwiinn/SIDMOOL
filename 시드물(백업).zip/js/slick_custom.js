$(function () {
    $(".lazy").slick({
        lazyLoad: "ondemand", // ondemand progressive anticipated
        infinite: true,
        arrow:false,
        dots:true,
        prevArrow:false,
        nextArrow:false,
    });
});
